class Food {
    constructor() {

    }    
}